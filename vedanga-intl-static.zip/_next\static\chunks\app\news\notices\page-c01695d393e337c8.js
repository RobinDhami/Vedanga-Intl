(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[7148],{5531:function(e,t,a){"use strict";a.d(t,{Z:function(){return l}});var r=a(2265);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=e=>e.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase(),i=(...e)=>e.filter((e,t,a)=>!!e&&a.indexOf(e)===t).join(" ");/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */var s={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"};/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let o=(0,r.forwardRef)(({color:e="currentColor",size:t=24,strokeWidth:a=2,absoluteStrokeWidth:n,className:o="",children:l,iconNode:c,...d},h)=>(0,r.createElement)("svg",{ref:h,...s,width:t,height:t,stroke:e,strokeWidth:n?24*Number(a)/Number(t):a,className:i("lucide",o),...d},[...c.map(([e,t])=>(0,r.createElement)(e,t)),...Array.isArray(l)?l:[l]])),l=(e,t)=>{let a=(0,r.forwardRef)(({className:a,...s},l)=>(0,r.createElement)(o,{ref:l,iconNode:t,className:i(`lucide-${n(e)}`,a),...s}));return a.displayName=`${e}`,a}},1351:function(e,t,a){"use strict";a.d(t,{Z:function(){return n}});var r=a(5531);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,r.Z)("CalendarDays",[["path",{d:"M8 2v4",key:"1cmpym"}],["path",{d:"M16 2v4",key:"4m81vk"}],["rect",{width:"18",height:"18",x:"3",y:"4",rx:"2",key:"1hopcy"}],["path",{d:"M3 10h18",key:"8toen8"}],["path",{d:"M8 14h.01",key:"6423bh"}],["path",{d:"M12 14h.01",key:"1etili"}],["path",{d:"M16 14h.01",key:"1gbofw"}],["path",{d:"M8 18h.01",key:"lrp35t"}],["path",{d:"M12 18h.01",key:"mhygvu"}],["path",{d:"M16 18h.01",key:"kzsmim"}]])},7158:function(e,t,a){"use strict";a.d(t,{Z:function(){return n}});var r=a(5531);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,r.Z)("ChevronRight",[["path",{d:"m9 18 6-6-6-6",key:"mthhwq"}]])},6141:function(e,t,a){"use strict";a.d(t,{Z:function(){return n}});var r=a(5531);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,r.Z)("Clock",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["polyline",{points:"12 6 12 12 16 14",key:"68esgv"}]])},3948:function(e,t,a){"use strict";a.d(t,{Z:function(){return n}});var r=a(5531);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,r.Z)("Megaphone",[["path",{d:"m3 11 18-5v12L3 14v-3z",key:"n962bs"}],["path",{d:"M11.6 16.8a3 3 0 1 1-5.8-1.6",key:"1yl0tm"}]])},9825:function(e,t,a){Promise.resolve().then(a.bind(a,9191))},9191:function(e,t,a){"use strict";a.r(t),a.d(t,{default:function(){return h}});var r=a(7437),n=a(9303),i=a(7158),s=a(5531);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let o=(0,s.Z)("School",[["path",{d:"M14 22v-4a2 2 0 1 0-4 0v4",key:"hhkicm"}],["path",{d:"m18 10 4 2v8a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2v-8l4-2",key:"1vwozw"}],["path",{d:"M18 5v17",key:"1sw6gf"}],["path",{d:"m4 6 8-4 8 4",key:"1q0ilc"}],["path",{d:"M6 5v17",key:"1xfsm0"}],["circle",{cx:"12",cy:"9",r:"2",key:"1092wv"}]]);var l=a(3948),c=a(1351),d=a(6141);function h(){let e=[{title:"Admission Open for Academic Year 2024-25",date:"2024-02-15",category:"Admissions",content:"Applications are now being accepted for all grades. Limited seats available. Early applications receive priority consideration for scholarships and financial aid.",icon:(0,r.jsx)(o,{className:"h-5 w-5"}),color:"bg-blue-100 text-blue-600"},{title:"Parent-Teacher Meeting Schedule",date:"2024-02-10",category:"Academic",content:"The first term parent-teacher meeting will be held on March 1st, 2024 from 2:00 PM to 5:00 PM. Please schedule your appointment through the parent portal.",icon:(0,r.jsx)(l.Z,{className:"h-5 w-5"}),color:"bg-purple-100 text-purple-600"},{title:"Holiday Notice: Holi Festival",date:"2024-02-05",category:"Holiday",content:"School will remain closed on March 25th, 2024 for Holi celebrations. Classes will resume on March 27th. Wishing all our students and staff a colorful and safe celebration!",icon:(0,r.jsx)(c.Z,{className:"h-5 w-5"}),color:"bg-green-100 text-green-600"}],t=e=>{let t=new Date(e),a=new Date,r=Math.floor((a.getTime()-t.getTime())/864e5);return 0===r?"Today":1===r?"Yesterday":r<7?"".concat(r," days ago"):r<30?"".concat(Math.floor(r/7)," week").concat(Math.floor(r/7)>1?"s":""," ago"):t.toLocaleDateString("en-US",{month:"short",day:"numeric",year:"numeric"})};return(0,r.jsx)("div",{className:"max-w-4xl mx-auto px-4 py-12 sm:px-6 lg:px-8",children:(0,r.jsxs)(n.E.div,{initial:{opacity:0,y:20},animate:{opacity:1,y:0},transition:{duration:.5},children:[(0,r.jsx)("h1",{className:"text-3xl sm:text-4xl font-bold mb-2 text-[#D41D33]",children:"Notices & Announcements"}),(0,r.jsx)("p",{className:"text-gray-600 mb-8",children:"Stay updated with the latest school news and important information"}),(0,r.jsx)("div",{className:"space-y-4",children:e.map((e,a)=>(0,r.jsx)(n.E.div,{initial:{opacity:0,y:20},animate:{opacity:1,y:0},transition:{duration:.1,delay:.05*a},whileHover:{y:-2},className:"bg-white rounded-xl shadow-sm border border-gray-100 hover:shadow-md transition-all overflow-hidden",children:(0,r.jsx)("div",{className:"p-6",children:(0,r.jsxs)("div",{className:"flex items-start gap-4",children:[(0,r.jsx)("div",{className:"p-3 ".concat(e.color," rounded-lg"),children:e.icon}),(0,r.jsxs)("div",{className:"flex-1",children:[(0,r.jsxs)("div",{className:"flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 mb-3",children:[(0,r.jsx)("span",{className:"px-3 py-1 ".concat(e.color," bg-opacity-20 rounded-full text-xs font-medium w-fit"),children:e.category}),(0,r.jsxs)("div",{className:"flex items-center text-sm text-gray-500",children:[(0,r.jsx)(d.Z,{className:"h-4 w-4 mr-1"}),(0,r.jsx)("span",{children:t(e.date)})]})]}),(0,r.jsx)("h2",{className:"text-xl font-semibold text-gray-800 mb-2",children:e.title}),(0,r.jsx)("p",{className:"text-gray-600 mb-4 line-clamp-2",children:e.content}),(0,r.jsxs)("button",{className:"flex items-center text-[#D41D33] hover:text-[#d54359] font-medium transition-colors group mr-2",children:["Read full notice",(0,r.jsx)(i.Z,{size:18})]})]})]})})},a))})]})})}}},function(e){e.O(0,[9303,2971,7864,1744],function(){return e(e.s=9825)}),_N_E=e.O()}]);