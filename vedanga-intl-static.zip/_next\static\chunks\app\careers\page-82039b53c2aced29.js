(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[6995],{5531:function(e,t,a){"use strict";a.d(t,{Z:function(){return c}});var s=a(2265);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=e=>e.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase(),i=(...e)=>e.filter((e,t,a)=>!!e&&a.indexOf(e)===t).join(" ");/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */var l={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"};/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=(0,s.forwardRef)(({color:e="currentColor",size:t=24,strokeWidth:a=2,absoluteStrokeWidth:r,className:n="",children:c,iconNode:d,...o},x)=>(0,s.createElement)("svg",{ref:x,...l,width:t,height:t,stroke:e,strokeWidth:r?24*Number(a)/Number(t):a,className:i("lucide",n),...o},[...d.map(([e,t])=>(0,s.createElement)(e,t)),...Array.isArray(c)?c:[c]])),c=(e,t)=>{let a=(0,s.forwardRef)(({className:a,...l},c)=>(0,s.createElement)(n,{ref:c,iconNode:t,className:i(`lucide-${r(e)}`,a),...l}));return a.displayName=`${e}`,a}},9057:function(e,t,a){"use strict";a.d(t,{Z:function(){return r}});var s=a(5531);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,s.Z)("Briefcase",[["path",{d:"M16 20V4a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16",key:"jecpp"}],["rect",{width:"20",height:"14",x:"2",y:"6",rx:"2",key:"i6l2r4"}]])},6141:function(e,t,a){"use strict";a.d(t,{Z:function(){return r}});var s=a(5531);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,s.Z)("Clock",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["polyline",{points:"12 6 12 12 16 14",key:"68esgv"}]])},3344:function(e,t,a){"use strict";a.d(t,{Z:function(){return r}});var s=a(5531);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,s.Z)("GraduationCap",[["path",{d:"M21.42 10.922a1 1 0 0 0-.019-1.838L12.83 5.18a2 2 0 0 0-1.66 0L2.6 9.08a1 1 0 0 0 0 1.832l8.57 3.908a2 2 0 0 0 1.66 0z",key:"j76jl0"}],["path",{d:"M22 10v6",key:"1lu8f3"}],["path",{d:"M6 12.5V16a6 3 0 0 0 12 0v-3.5",key:"1r8lef"}]])},498:function(e,t,a){Promise.resolve().then(a.bind(a,2971))},2971:function(e,t,a){"use strict";a.r(t),a.d(t,{default:function(){return m}});var s=a(7437),r=a(9303),i=a(5531);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let l=(0,i.Z)("CircleX",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"m15 9-6 6",key:"1uzhvr"}],["path",{d:"m9 9 6 6",key:"z0biqf"}]]);var n=a(9057),c=a(6141),d=a(3344),o=a(2265),x=a(1789);function m(){let[e,t]=(0,o.useState)([]);return(0,o.useEffect)(()=>{let e=async()=>{let e=await (0,x.$y)();t(e.jobOpenings)};e()},[]),(0,s.jsx)("div",{className:"min-h-screen bg-gray-50 py-12 px-4 sm:px-6 lg:px-8",children:(0,s.jsx)("div",{className:"max-w-7xl mx-auto",children:0===e.length?(0,s.jsxs)("div",{className:"text-center py-40",children:[(0,s.jsx)("div",{className:"inline-flex items-center justify-center w-20 h-20 mb-8 bg-red-100 text-red-600 rounded-full",children:(0,s.jsx)(l,{className:"h-12 w-12"})}),(0,s.jsx)("h2",{className:"text-2xl md:text-4xl font-bold text-gray-300 mb-4",children:"No Job Openings Available"})]}):(0,s.jsxs)(s.Fragment,{children:[(0,s.jsxs)(r.E.div,{className:"text-center mb-16",initial:{opacity:0,y:20},animate:{opacity:1,y:0},transition:{duration:.5},children:[(0,s.jsx)("h1",{className:"text-4xl font-bold text-[#DB2139] mb-4",children:"Join Our Team"}),(0,s.jsx)("p",{className:"text-lg text-gray-600 max-w-3xl mx-auto",children:"Explore career opportunities at Vedanga International School"})]}),(0,s.jsx)("div",{className:"grid gap-8 md:grid-cols-2 lg:grid-cols-3 mb-16",children:e.map((e,t)=>(0,s.jsx)(r.E.div,{className:"bg-white rounded-2xl shadow-md overflow-hidden hover:shadow-lg transition-all duration-300 border border-gray-100",initial:{opacity:0,y:20},animate:{opacity:1,y:0},transition:{duration:.1,delay:.025*t},whileHover:{y:-5},children:(0,s.jsxs)("div",{className:"p-6 h-full flex flex-col",children:[(0,s.jsxs)("div",{className:"flex items-start space-x-4 mb-4",children:[(0,s.jsx)("div",{className:"p-3 rounded-lg bg-red-100 text-red-600",children:(0,s.jsx)(n.Z,{className:"h-6 w-6"})}),(0,s.jsxs)("div",{children:[(0,s.jsx)("h3",{className:"text-xl font-bold text-gray-900",children:e.title}),(0,s.jsx)("div",{className:"mt-1",children:(0,s.jsx)("span",{className:"inline-block px-2 py-1 text-xs font-medium bg-gray-100 text-gray-600 rounded-full",children:e.department})})]})]}),(0,s.jsx)("p",{className:"text-gray-600 mb-5 flex-grow",children:e.description}),(0,s.jsxs)("div",{className:"space-y-3 mb-5",children:[(0,s.jsxs)("div",{className:"flex items-center text-sm text-gray-600",children:[(0,s.jsx)(c.Z,{className:"h-4 w-4 mr-2 text-gray-400"}),(0,s.jsx)("span",{children:e.employment_type})]}),(0,s.jsxs)("div",{className:"flex items-center text-sm text-gray-600",children:[(0,s.jsx)(n.Z,{className:"h-4 w-4 mr-2 text-gray-400"}),(0,s.jsxs)("span",{children:[e.experience," experience"]})]}),(0,s.jsxs)("div",{className:"flex items-center text-sm text-gray-600",children:[(0,s.jsx)(d.Z,{className:"h-4 w-4 mr-2 text-gray-400"}),(0,s.jsx)("span",{children:e.education})]})]}),(0,s.jsx)("div",{className:"mt-auto rounded-lg bg-gray-100 px-4 py-2.5 text-sm font-medium text-gray-600",children:"Applications open through the school office"})]})},e.id))})]})})})}}},function(e){e.O(0,[9303,2117,1789,2971,7864,1744],function(){return e(e.s=498)}),_N_E=e.O()}]);