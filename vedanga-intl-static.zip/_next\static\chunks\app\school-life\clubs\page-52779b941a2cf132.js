(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[6369],{5531:function(e,t,r){"use strict";r.d(t,{Z:function(){return c}});var s=r(2265);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=e=>e.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase(),i=(...e)=>e.filter((e,t,r)=>!!e&&r.indexOf(e)===t).join(" ");/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */var n={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"};/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let l=(0,s.forwardRef)(({color:e="currentColor",size:t=24,strokeWidth:r=2,absoluteStrokeWidth:a,className:l="",children:c,iconNode:o,...d},u)=>(0,s.createElement)("svg",{ref:u,...n,width:t,height:t,stroke:e,strokeWidth:a?24*Number(r)/Number(t):r,className:i("lucide",l),...d},[...o.map(([e,t])=>(0,s.createElement)(e,t)),...Array.isArray(c)?c:[c]])),c=(e,t)=>{let r=(0,s.forwardRef)(({className:r,...n},c)=>(0,s.createElement)(l,{ref:c,iconNode:t,className:i(`lucide-${a(e)}`,r),...n}));return r.displayName=`${e}`,r}},4035:function(e,t,r){"use strict";r.d(t,{Z:function(){return a}});var s=r(5531);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,s.Z)("Camera",[["path",{d:"M14.5 4h-5L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3l-2.5-3z",key:"1tc9qg"}],["circle",{cx:"12",cy:"13",r:"3",key:"1vg3eu"}]])},7158:function(e,t,r){"use strict";r.d(t,{Z:function(){return a}});var s=r(5531);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,s.Z)("ChevronRight",[["path",{d:"m9 18 6-6-6-6",key:"mthhwq"}]])},2455:function(e,t,r){"use strict";r.d(t,{Z:function(){return a}});var s=r(5531);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,s.Z)("Code",[["polyline",{points:"16 18 22 12 16 6",key:"z7tu5w"}],["polyline",{points:"8 6 2 12 8 18",key:"1eg1df"}]])},4043:function(e,t,r){"use strict";r.d(t,{Z:function(){return a}});var s=r(5531);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,s.Z)("Mic",[["path",{d:"M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z",key:"131961"}],["path",{d:"M19 10v2a7 7 0 0 1-14 0v-2",key:"1vc78b"}],["line",{x1:"12",x2:"12",y1:"19",y2:"22",key:"x3vr5v"}]])},7187:function(e,t,r){"use strict";r.d(t,{Z:function(){return a}});var s=r(5531);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,s.Z)("Music",[["path",{d:"M9 18V5l12-2v13",key:"1jmyc2"}],["circle",{cx:"6",cy:"18",r:"3",key:"fqmcym"}],["circle",{cx:"18",cy:"16",r:"3",key:"1hluhg"}]])},597:function(e,t,r){"use strict";r.d(t,{Z:function(){return a}});var s=r(5531);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,s.Z)("Palette",[["circle",{cx:"13.5",cy:"6.5",r:".5",fill:"currentColor",key:"1okk4w"}],["circle",{cx:"17.5",cy:"10.5",r:".5",fill:"currentColor",key:"f64h9f"}],["circle",{cx:"8.5",cy:"7.5",r:".5",fill:"currentColor",key:"fotxhn"}],["circle",{cx:"6.5",cy:"12.5",r:".5",fill:"currentColor",key:"qy21gx"}],["path",{d:"M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.926 0 1.648-.746 1.648-1.688 0-.437-.18-.835-.437-1.125-.29-.289-.438-.652-.438-1.125a1.64 1.64 0 0 1 1.668-1.668h1.996c3.051 0 5.555-2.503 5.555-5.554C21.965 6.012 17.461 2 12 2z",key:"12rzf8"}]])},5750:function(e,t,r){"use strict";r.d(t,{Z:function(){return a}});var s=r(5531);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,s.Z)("Users",[["path",{d:"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",key:"1yyitq"}],["circle",{cx:"9",cy:"7",r:"4",key:"nufk8"}],["path",{d:"M22 21v-2a4 4 0 0 0-3-3.87",key:"kshegd"}],["path",{d:"M16 3.13a4 4 0 0 1 0 7.75",key:"1da9ce"}]])},1167:function(e,t,r){Promise.resolve().then(r.bind(r,2091))},2091:function(e,t,r){"use strict";r.r(t),r.d(t,{default:function(){return p}});var s=r(7437),a=r(9303),i=r(1396),n=r.n(i),l=r(2455),c=r(4035),o=r(4043),d=r(597),u=r(7187),m=r(5750),x=r(7158),h=r(2265),f=r(1789);let y={code:l.Z,camera:c.Z,mic:o.Z,palette:d.Z,music:u.Z};function p(){let[e,t]=(0,h.useState)([]);return(0,h.useEffect)(()=>{let e=async()=>{let e=await (0,f.Er)();t(e)};e()},[]),(0,s.jsx)("div",{className:"min-h-screen bg-gray-50 py-12 px-4 sm:px-6 lg:px-8",children:(0,s.jsxs)("div",{className:"max-w-7xl mx-auto",children:[(0,s.jsxs)(a.E.div,{className:"text-center mb-16",initial:{opacity:0,y:20},animate:{opacity:1,y:0},transition:{duration:.5},children:[(0,s.jsx)("h1",{className:"text-4xl font-bold text-[#DB2139] mb-4",children:"Student Clubs & Organizations"}),(0,s.jsx)("p",{className:"text-lg text-gray-600 max-w-3xl mx-auto",children:"Discover your passion, develop new skills, and connect with like-minded peers through our diverse range of student-led clubs."})]}),(0,s.jsx)("div",{className:"grid gap-8 md:grid-cols-2 lg:grid-cols-3",children:e.map((e,t)=>{var r;let i=null!==(r=y[e.icon_name])&&void 0!==r?r:l.Z;return(0,s.jsx)(a.E.div,{className:"bg-white rounded-2xl shadow-md overflow-hidden hover:shadow-lg transition-all duration-300 border border-gray-100",initial:{opacity:0,y:20},animate:{opacity:1,y:0},transition:{duration:.1,delay:.05*t},whileHover:{y:-5},children:(0,s.jsxs)("div",{className:"p-6 h-full flex flex-col",children:[(0,s.jsxs)("div",{className:"flex items-start space-x-4 mb-4",children:[(0,s.jsx)("div",{className:"p-3 bg-[#D41D33]/10 text-[#D41D33] rounded-lg",children:(0,s.jsx)(i,{className:"h-6 w-6"})}),(0,s.jsxs)("div",{children:[(0,s.jsx)("h3",{className:"text-xl font-bold text-gray-900",children:e.name}),(0,s.jsxs)("div",{className:"flex items-center mt-1 text-sm text-gray-500",children:[(0,s.jsx)(m.Z,{className:"h-4 w-4 mr-1"}),(0,s.jsxs)("span",{children:[e.members," members"]})]})]})]}),(0,s.jsx)("p",{className:"text-gray-600 mb-5 flex-grow",children:e.description}),(0,s.jsxs)("div",{className:"mb-5",children:[(0,s.jsx)("h4",{className:"text-sm font-semibold text-gray-700 mb-2 uppercase tracking-wider",children:"Activities"}),(0,s.jsx)("div",{className:"flex flex-wrap gap-2",children:e.activities.map((e,t)=>(0,s.jsx)("span",{className:"px-2.5 py-1 bg-gray-50 rounded-full text-xs font-medium text-gray-600 border border-gray-200",children:e},t))})]}),(0,s.jsxs)("div",{className:"mt-auto pt-4 border-t border-gray-100",children:[(0,s.jsxs)("div",{className:"flex flex-col xl:flex-row md:justify-between text-sm text-gray-500 mb-4",children:[(0,s.jsxs)("div",{className:"flex items-center",children:[(0,s.jsx)("span",{className:"font-medium",children:"Advisor:"}),(0,s.jsx)("span",{className:"ml-1",children:e.advisor||"TBA"})]}),(0,s.jsxs)("div",{className:"flex items-center",children:[(0,s.jsx)("span",{className:"font-medium",children:"Meets: "}),(0,s.jsx)("span",{className:"ml-1",children:e.meeting_day||"TBA"})]})]}),(0,s.jsx)(n(),{href:"/school-life/clubs/".concat(e.slug),children:(0,s.jsxs)("button",{className:"w-full flex items-center justify-center px-4 py-2.5 bg-[#DB2139] text-white rounded-lg hover:bg-[#e94158] transition-colors group",children:[(0,s.jsx)("span",{className:"font-medium",children:"View details"}),(0,s.jsx)(x.Z,{className:"h-4 w-4 transition-transform group-hover:translate-x-1"})]})})]})]})},e.slug)})})]})})}},1396:function(e,t,r){e.exports=r(4724)}},function(e){e.O(0,[4724,9303,2117,1789,2971,7864,1744],function(){return e(e.s=1167)}),_N_E=e.O()}]);